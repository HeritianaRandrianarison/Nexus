# NEXUS — Centre de contrôle Android natif

Application Android native (Kotlin, Jetpack Compose, Material 3, Clean Architecture + MVVM) fonctionnant selon une approche **offline-first** sans compte ni serveur obligatoire.

## Identité du projet
- **Application ID** : `com.nexus.mobile`
- **Minimum SDK** : API 26 (Android 8.0)
- **Target / Compile SDK** : API 35 (Android 15)
- **Architecture** : Clean Architecture (`core`, `domain`, `data`, `feature`, `presentation`) + MVVM
- **Build System** : Gradle Kotlin DSL + Version Catalog (`gradle/libs.versions.toml`)

## Prérequis
- **JDK** : 17 (inclus avec Android Studio)
- **Android Studio** : Ladybug (2024.2.1) ou plus récent
- **Android SDK** : Platform 35 + Build-Tools 35.0.0

## Initialisation Git & Build rapide

### Sur Android (Termux + Git)
```bash
# 1. Installer les outils dans Termux
pkg update && pkg install -y git unzip openjdk-17 gradle aapt2

# 2. Décompresser et initialiser Git
unzip NEXUS-android-sprint1.zip -d ~/
cd ~/NEXUS
git init
git branch -M main
git add .
git commit -m "chore(sprint1): initialize NEXUS Android foundation"

# 3. Générer le wrapper et compiler localement (avec aapt2 ARM64)
gradle wrapper --gradle-version 8.11.1
./gradlew testDebugUnitTest assembleDebug -Pandroid.aapt2FromMavenOverride=$(which aapt2)
```

### Via GitHub Actions (inclus dans .github/workflows/build-apk.yml)
Poussez simplement le dépôt sur GitHub depuis Android (`git push -u origin main`) pour obtenir automatiquement `app-debug.apk` dans l'onglet **Actions**.

### Sur PC (Linux / macOS / Windows + Android Studio)
```bash
git init && git add . && git commit -m "chore(sprint1): initialize NEXUS Android foundation"
gradle wrapper --gradle-version 8.11.1
./gradlew testDebugUnitTest assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## Roadmap des Sprints
- **Sprint 1 — Foundation** : Projet natif, Gradle/Compose, thème NEXUS, navigation 5 onglets et Dashboard initial.
- **Sprint 2 — Core Infrastructure** : Room, DataStore, modèles persistants et journal d'événements.
- **Sprint 3 — Web Sentinel** : Surveillance HTTP, snapshots, diff et WorkManager.
- **Sprint 4 — Smart Alert** : Canaux de notification Android et déduplication.
- **Sprint 5 — Network Intelligence** : Diagnostic réseau local, DNS et limites Android.
- **Sprint 6 — Automation Engine** : Moteur de règles DÉCLENCHEUR → CONDITIONS → ACTIONS.
- **Sprint 7 — Intelligence Assistant** : Analyse locale déterministe et recherche.
- **Sprint 8 — Finalisation** : Tests complets, audit sécurité et APK Release.
