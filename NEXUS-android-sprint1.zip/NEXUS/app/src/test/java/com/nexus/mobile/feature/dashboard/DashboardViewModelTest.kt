package com.nexus.mobile.feature.dashboard

import com.nexus.mobile.data.repository.InMemoryDashboardRepository
import com.nexus.mobile.domain.usecase.GetDashboardOverviewUseCase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class DashboardViewModelTest {

    private val testDispatcher = StandardTestDispatcher()

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `uiState emits Ready with six NEXUS modules and initial events`() = runTest {
        val repository = InMemoryDashboardRepository()
        val viewModel = DashboardViewModel(GetDashboardOverviewUseCase(repository))

        val readyState = viewModel.uiState.first { it is DashboardUiState.Ready } as DashboardUiState.Ready

        assertEquals(6, readyState.modules.size)
        assertTrue(readyState.overview.offlineFirstActive)
        assertEquals(2, readyState.recentActivities.size)
    }

    @Test
    fun `refresh appends a local verification event`() = runTest {
        val repository = InMemoryDashboardRepository()
        val viewModel = DashboardViewModel(GetDashboardOverviewUseCase(repository))

        val initial = viewModel.uiState.first { it is DashboardUiState.Ready } as DashboardUiState.Ready
        viewModel.refresh()
        testDispatcher.scheduler.advanceUntilIdle()
        val updated = viewModel.uiState.first {
            it is DashboardUiState.Ready && it.recentActivities.size > initial.recentActivities.size
        } as DashboardUiState.Ready

        assertEquals(initial.recentActivities.size + 1, updated.recentActivities.size)
        assertEquals("Vérification locale effectuée", updated.recentActivities.first().title)
    }
}
