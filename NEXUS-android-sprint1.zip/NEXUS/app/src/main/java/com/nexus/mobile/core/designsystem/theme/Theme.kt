package com.nexus.mobile.core.designsystem.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val NexusDarkColorScheme = darkColorScheme(
    primary = NexusGreen,
    onPrimary = NexusOnGreen,
    secondary = NexusViolet,
    onSecondary = NexusOnViolet,
    background = NexusBackground,
    onBackground = NexusTextPrimary,
    surface = NexusSurface,
    onSurface = NexusTextPrimary,
    surfaceVariant = NexusSurfaceVariant,
    onSurfaceVariant = NexusTextSecondary,
    outline = NexusOutline,
    error = NexusError,
    onError = NexusTextPrimary,
)

@Composable
fun NexusTheme(
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = NexusDarkColorScheme,
        typography = NexusTypography,
        content = content,
    )
}
