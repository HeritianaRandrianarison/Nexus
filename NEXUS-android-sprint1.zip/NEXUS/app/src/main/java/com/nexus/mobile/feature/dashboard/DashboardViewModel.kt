package com.nexus.mobile.feature.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.nexus.mobile.data.repository.InMemoryDashboardRepository
import com.nexus.mobile.domain.usecase.GetDashboardOverviewUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DashboardViewModel(
    private val getDashboardOverview: GetDashboardOverviewUseCase,
) : ViewModel() {

    private val isRefreshing = MutableStateFlow(false)

    val uiState: StateFlow<DashboardUiState> = combine(
        getDashboardOverview(),
        isRefreshing,
    ) { data, refreshing ->
        DashboardUiState.Ready(
            overview = data.overview,
            modules = data.modules,
            recentActivities = data.recentActivities,
            isRefreshing = refreshing,
        ) as DashboardUiState
    }.catch { throwable ->
        emit(
            DashboardUiState.Error(
                message = throwable.localizedMessage ?: "Erreur lors du chargement du tableau de bord.",
            ),
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = DashboardUiState.Loading,
    )

    fun refresh() {
        viewModelScope.launch {
            isRefreshing.value = true
            try {
                getDashboardOverview.refresh()
            } finally {
                isRefreshing.value = false
            }
        }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                val repository = InMemoryDashboardRepository()
                val useCase = GetDashboardOverviewUseCase(repository)
                return DashboardViewModel(useCase) as T
            }
        }
    }
}
