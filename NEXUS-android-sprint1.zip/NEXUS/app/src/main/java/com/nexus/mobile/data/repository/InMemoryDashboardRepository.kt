package com.nexus.mobile.data.repository

import com.nexus.mobile.domain.model.ModuleStatus
import com.nexus.mobile.domain.model.ModuleSummary
import com.nexus.mobile.domain.model.ModuleType
import com.nexus.mobile.domain.model.PriorityLevel
import com.nexus.mobile.domain.model.RecentActivityItem
import com.nexus.mobile.domain.model.SystemOverview
import com.nexus.mobile.domain.repository.DashboardRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.LocalTime
import java.time.format.DateTimeFormatter

/**
 * Implémentation locale en mémoire pour le Sprint 1 (Foundation).
 * Sera remplacée par les DAO Room et DataStore au Sprint 2 sans modifier les ViewModels.
 */
class InMemoryDashboardRepository : DashboardRepository {

    private val timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss")

    private val overviewState = MutableStateFlow(
        SystemOverview(
            appVersion = "1.0.0-sprint1",
            offlineFirstActive = true,
            activeModulesCount = 1,
            monitoredTargetsCount = 0,
            activeRulesCount = 0,
            unreadAlertsCount = 0,
        ),
    )

    private val modulesState = MutableStateFlow(
        listOf(
            ModuleSummary(
                type = ModuleType.WEB_SENTINEL,
                title = "Web Sentinel",
                subtitle = "Surveillance HTTP, snapshots et mots-clés",
                status = ModuleStatus.PLANNED,
                sprintLabel = "Sprint 3",
                itemCount = 0,
            ),
            ModuleSummary(
                type = ModuleType.NETWORK_INTELLIGENCE,
                title = "Network Intelligence",
                subtitle = "Diagnostic local, DNS et disponibilité hôtes",
                status = ModuleStatus.PLANNED,
                sprintLabel = "Sprint 5",
                itemCount = 0,
            ),
            ModuleSummary(
                type = ModuleType.AUTOMATION_ENGINE,
                title = "Automation Engine",
                subtitle = "Règles locales DÉCLENCHEUR → CONDITIONS → ACTIONS",
                status = ModuleStatus.PLANNED,
                sprintLabel = "Sprint 6",
                itemCount = 0,
            ),
            ModuleSummary(
                type = ModuleType.INTELLIGENCE_ASSISTANT,
                title = "Intelligence Assistant",
                subtitle = "Analyse locale déterministe et recherche",
                status = ModuleStatus.PLANNED,
                sprintLabel = "Sprint 7",
                itemCount = 0,
            ),
            ModuleSummary(
                type = ModuleType.SMART_ALERT,
                title = "Smart Alert",
                subtitle = "Canaux Android, priorités et déduplication",
                status = ModuleStatus.PLANNED,
                sprintLabel = "Sprint 4",
                itemCount = 0,
            ),
            ModuleSummary(
                type = ModuleType.EVENT_INTELLIGENCE,
                title = "Event Intelligence",
                subtitle = "Journal unifié et export CSV / JSON",
                status = ModuleStatus.CONFIGURED,
                sprintLabel = "Sprint 2",
                itemCount = 2,
            ),
        ),
    )

    private val activitiesState = MutableStateFlow(
        listOf(
            RecentActivityItem(
                id = "evt-init-1",
                module = ModuleType.EVENT_INTELLIGENCE,
                title = "Initialisation du socle NEXUS",
                detail = "Clean Architecture, thème sombre et navigation active.",
                timestampLabel = LocalTime.now().format(timeFormatter),
                priority = PriorityLevel.NORMAL,
            ),
            RecentActivityItem(
                id = "evt-init-2",
                module = ModuleType.EVENT_INTELLIGENCE,
                title = "Mode hors-ligne vérifié",
                detail = "Aucun compte ni serveur distant requis au démarrage.",
                timestampLabel = LocalTime.now().format(timeFormatter),
                priority = PriorityLevel.LOW,
            ),
        ),
    )

    override fun observeSystemOverview(): Flow<SystemOverview> = overviewState.asStateFlow()

    override fun observeModules(): Flow<List<ModuleSummary>> = modulesState.asStateFlow()

    override fun observeRecentActivities(): Flow<List<RecentActivityItem>> = activitiesState.asStateFlow()

    override suspend fun refreshOverview() {
        val current = activitiesState.value
        val refreshEvent = RecentActivityItem(
            id = "evt-refresh-${System.currentTimeMillis()}",
            module = ModuleType.EVENT_INTELLIGENCE,
            title = "Vérification locale effectuée",
            detail = "État des modules actualisé hors-ligne.",
            timestampLabel = LocalTime.now().format(timeFormatter),
            priority = PriorityLevel.LOW,
        )
        activitiesState.value = listOf(refreshEvent) + current.take(9)
    }
}
