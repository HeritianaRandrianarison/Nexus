package com.nexus.mobile.core.designsystem.theme

import androidx.compose.ui.graphics.Color

val NexusBackground = Color(0xFF101216)
val NexusSurface = Color(0xFF1B2028)
val NexusSurfaceVariant = Color(0xFF232A35)
val NexusOutline = Color(0xFF2E3746)

val NexusGreen = Color(0xFFA3F75B)
val NexusOnGreen = Color(0xFF0E1608)
val NexusViolet = Color(0xFFA78BFA)
val NexusOnViolet = Color(0xFF161124)

val NexusTextPrimary = Color(0xFFF1F5F9)
val NexusTextSecondary = Color(0xFF94A3B8)

val NexusWarning = Color(0xFFF59E0B)
val NexusError = Color(0xFFEF4444)
