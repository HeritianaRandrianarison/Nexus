package com.nexus.mobile.presentation.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.nexus.mobile.core.designsystem.theme.NexusBackground
import com.nexus.mobile.core.designsystem.theme.NexusGreen
import com.nexus.mobile.core.designsystem.theme.NexusOnGreen
import com.nexus.mobile.core.designsystem.theme.NexusSurface
import com.nexus.mobile.core.designsystem.theme.NexusTextSecondary
import com.nexus.mobile.feature.dashboard.DashboardRoute
import com.nexus.mobile.feature.placeholder.SprintModulePlaceholderScreen

@Composable
fun NexusNavHost() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    val navigateToTopLevel: (NexusDestination) -> Unit = { destination ->
        navController.navigate(destination.route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        containerColor = NexusBackground,
        bottomBar = {
            NavigationBar(containerColor = NexusSurface) {
                NexusDestination.entries.forEach { destination ->
                    val selected = currentDestination?.hierarchy?.any {
                        it.route == destination.route
                    } == true

                    NavigationBarItem(
                        selected = selected,
                        onClick = { navigateToTopLevel(destination) },
                        icon = {
                            Icon(
                                imageVector = destination.icon,
                                contentDescription = destination.label,
                            )
                        },
                        label = { Text(destination.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NexusOnGreen,
                            selectedTextColor = NexusGreen,
                            indicatorColor = NexusGreen,
                            unselectedIconColor = NexusTextSecondary,
                            unselectedTextColor = NexusTextSecondary,
                        ),
                    )
                }
            }
        },
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = NexusDestination.DASHBOARD.route,
            modifier = Modifier.padding(innerPadding),
        ) {
            composable(NexusDestination.DASHBOARD.route) {
                DashboardRoute(
                    onOpenMonitor = { navigateToTopLevel(NexusDestination.MONITOR) },
                    onOpenAutomations = { navigateToTopLevel(NexusDestination.AUTOMATIONS) },
                    onOpenActivity = { navigateToTopLevel(NexusDestination.ACTIVITY) },
                )
            }

            composable(NexusDestination.MONITOR.route) {
                SprintModulePlaceholderScreen(
                    title = "Monitor",
                    sprintTarget = "Sprints 3 & 5",
                    summary = "Regroupe Web Sentinel (surveillance URL, extraction texte, diff snapshots) et Network Intelligence (connectivité, DNS, réseau local).",
                    plannedCapabilities = listOf(
                        "Ajouter et planifier des cibles web avec WorkManager",
                        "Détecter les changements et mots-clés",
                        "Tester la connectivité et les hôtes du réseau local",
                    ),
                )
            }

            composable(NexusDestination.AUTOMATIONS.route) {
                SprintModulePlaceholderScreen(
                    title = "Automations",
                    sprintTarget = "Sprint 6",
                    summary = "Moteur local de règles DÉCLENCHEUR → CONDITIONS → ACTIONS avec protection anti-boucles et journalisation complète.",
                    plannedCapabilities = listOf(
                        "Conditions composables AND / OR",
                        "Déclencheurs web, réseau et événements",
                        "Validation de règle avant activation",
                    ),
                )
            }

            composable(NexusDestination.ACTIVITY.route) {
                SprintModulePlaceholderScreen(
                    title = "Activity",
                    sprintTarget = "Sprints 2, 4 & 7",
                    summary = "Chronologie centralisée des événements, historique des alertes Smart Alert et recherche locale via Intelligence Assistant.",
                    plannedCapabilities = listOf(
                        "Filtrage par date, module, type et priorité",
                        "Export CSV et JSON des journaux",
                        "Résumés et explications déterministes hors-ligne",
                    ),
                )
            }

            composable(NexusDestination.SETTINGS.route) {
                SprintModulePlaceholderScreen(
                    title = "Settings",
                    sprintTarget = "Sprints 2 & 8",
                    summary = "Préférences DataStore, rétention de l'historique, canaux de notifications Android et audit des permissions.",
                    plannedCapabilities = listOf(
                        "Rétention configurable de la base Room",
                        "Préférences Smart Alert et seuils de déduplication",
                        "Informations de sécurité et mode hors-ligne",
                    ),
                )
            }
        }
    }
}
