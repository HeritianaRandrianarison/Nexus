package com.nexus.mobile.domain.model

enum class ModuleType {
    WEB_SENTINEL,
    NETWORK_INTELLIGENCE,
    AUTOMATION_ENGINE,
    INTELLIGENCE_ASSISTANT,
    SMART_ALERT,
    EVENT_INTELLIGENCE,
}

enum class ModuleStatus {
    READY,
    CONFIGURED,
    PLANNED,
}

enum class PriorityLevel {
    LOW,
    NORMAL,
    HIGH,
    CRITICAL,
}

data class ModuleSummary(
    val type: ModuleType,
    val title: String,
    val subtitle: String,
    val status: ModuleStatus,
    val sprintLabel: String,
    val itemCount: Int,
)

data class SystemOverview(
    val appVersion: String,
    val offlineFirstActive: Boolean,
    val activeModulesCount: Int,
    val monitoredTargetsCount: Int,
    val activeRulesCount: Int,
    val unreadAlertsCount: Int,
)

data class RecentActivityItem(
    val id: String,
    val module: ModuleType,
    val title: String,
    val detail: String,
    val timestampLabel: String,
    val priority: PriorityLevel,
)
