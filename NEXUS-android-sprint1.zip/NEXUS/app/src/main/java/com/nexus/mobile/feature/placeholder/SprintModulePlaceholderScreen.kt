package com.nexus.mobile.feature.placeholder

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nexus.mobile.core.designsystem.theme.NexusGreen
import com.nexus.mobile.core.designsystem.theme.NexusOutline
import com.nexus.mobile.core.designsystem.theme.NexusSurface
import com.nexus.mobile.core.designsystem.theme.NexusTextSecondary

@Composable
fun SprintModulePlaceholderScreen(
    title: String,
    sprintTarget: String,
    summary: String,
    plannedCapabilities: List<String>,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Text(
                text = "Prévu au $sprintTarget",
                style = MaterialTheme.typography.labelMedium,
                color = NexusGreen,
            )
        }

        Surface(
            color = NexusSurface,
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, NexusOutline),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = summary,
                    style = MaterialTheme.typography.bodyMedium,
                    color = NexusTextSecondary,
                )
                Spacer(modifier = Modifier.height(14.dp))
                plannedCapabilities.forEach { capability ->
                    Text(
                        text = "• $capability",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(vertical = 3.dp),
                    )
                }
            }
        }
    }
}
