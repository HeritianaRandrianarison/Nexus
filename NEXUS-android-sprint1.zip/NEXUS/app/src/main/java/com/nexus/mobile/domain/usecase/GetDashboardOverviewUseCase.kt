package com.nexus.mobile.domain.usecase

import com.nexus.mobile.domain.model.ModuleSummary
import com.nexus.mobile.domain.model.RecentActivityItem
import com.nexus.mobile.domain.model.SystemOverview
import com.nexus.mobile.domain.repository.DashboardRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

data class DashboardOverviewData(
    val overview: SystemOverview,
    val modules: List<ModuleSummary>,
    val recentActivities: List<RecentActivityItem>,
)

class GetDashboardOverviewUseCase(
    private val repository: DashboardRepository,
) {
    operator fun invoke(): Flow<DashboardOverviewData> {
        return combine(
            repository.observeSystemOverview(),
            repository.observeModules(),
            repository.observeRecentActivities(),
        ) { overview, modules, activities ->
            DashboardOverviewData(
                overview = overview,
                modules = modules,
                recentActivities = activities,
            )
        }
    }

    suspend fun refresh() {
        repository.refreshOverview()
    }
}
