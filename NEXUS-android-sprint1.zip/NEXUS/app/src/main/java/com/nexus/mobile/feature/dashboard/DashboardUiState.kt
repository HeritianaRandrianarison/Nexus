package com.nexus.mobile.feature.dashboard

import com.nexus.mobile.domain.model.ModuleSummary
import com.nexus.mobile.domain.model.RecentActivityItem
import com.nexus.mobile.domain.model.SystemOverview

sealed interface DashboardUiState {
    data object Loading : DashboardUiState

    data class Ready(
        val overview: SystemOverview,
        val modules: List<ModuleSummary>,
        val recentActivities: List<RecentActivityItem>,
        val isRefreshing: Boolean = false,
    ) : DashboardUiState

    data class Error(
        val message: String,
    ) : DashboardUiState
}
