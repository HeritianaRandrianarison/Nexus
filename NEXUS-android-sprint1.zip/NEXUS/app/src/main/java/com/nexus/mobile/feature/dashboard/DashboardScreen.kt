package com.nexus.mobile.feature.dashboard

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoMode
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nexus.mobile.core.designsystem.theme.NexusGreen
import com.nexus.mobile.core.designsystem.theme.NexusOutline
import com.nexus.mobile.core.designsystem.theme.NexusSurface
import com.nexus.mobile.core.designsystem.theme.NexusSurfaceVariant
import com.nexus.mobile.core.designsystem.theme.NexusTextSecondary
import com.nexus.mobile.core.designsystem.theme.NexusViolet
import com.nexus.mobile.domain.model.ModuleStatus
import com.nexus.mobile.domain.model.ModuleSummary
import com.nexus.mobile.domain.model.ModuleType
import com.nexus.mobile.domain.model.RecentActivityItem

@Composable
fun DashboardRoute(
    onOpenMonitor: () -> Unit,
    onOpenAutomations: () -> Unit,
    onOpenActivity: () -> Unit,
    viewModel: DashboardViewModel = viewModel(factory = DashboardViewModel.Factory),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    DashboardScreen(
        uiState = uiState,
        onRefresh = viewModel::refresh,
        onOpenMonitor = onOpenMonitor,
        onOpenAutomations = onOpenAutomations,
        onOpenActivity = onOpenActivity,
    )
}

@Composable
fun DashboardScreen(
    uiState: DashboardUiState,
    onRefresh: () -> Unit,
    onOpenMonitor: () -> Unit,
    onOpenAutomations: () -> Unit,
    onOpenActivity: () -> Unit,
) {
    when (uiState) {
        DashboardUiState.Loading -> {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center,
            ) {
                CircularProgressIndicator(color = NexusGreen)
            }
        }

        is DashboardUiState.Error -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = uiState.message,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error,
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(onClick = onRefresh) {
                        Text("Réessayer")
                    }
                }
            }
        }

        is DashboardUiState.Ready -> {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column {
                            Text(
                                text = "NEXUS",
                                style = MaterialTheme.typography.headlineMedium,
                                color = MaterialTheme.colorScheme.onBackground,
                            )
                            Text(
                                text = "Centre de contrôle local · ${uiState.overview.appVersion}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = NexusTextSecondary,
                            )
                        }
                        IconButton(onClick = onRefresh) {
                            Icon(
                                imageVector = Icons.Outlined.Refresh,
                                contentDescription = "Actualiser",
                                tint = NexusGreen,
                            )
                        }
                    }
                }

                item {
                    OverviewSummaryCard(
                        offlineFirstActive = uiState.overview.offlineFirstActive,
                        monitoredTargets = uiState.overview.monitoredTargetsCount,
                        activeRules = uiState.overview.activeRulesCount,
                        unreadAlerts = uiState.overview.unreadAlertsCount,
                        onOpenMonitor = onOpenMonitor,
                        onOpenAutomations = onOpenAutomations,
                    )
                }

                item {
                    Text(
                        text = "Modules NEXUS",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                }

                items(uiState.modules, key = { it.type.name }) { module ->
                    ModuleCard(module = module)
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = "Activité récente",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onBackground,
                        )
                        OutlinedButton(
                            onClick = onOpenActivity,
                            border = BorderStroke(1.dp, NexusOutline),
                        ) {
                            Text("Journal complet", color = NexusTextSecondary)
                        }
                    }
                }

                if (uiState.recentActivities.isEmpty()) {
                    item {
                        Surface(
                            color = NexusSurface,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, NexusOutline),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(
                                text = "Aucun événement enregistré pour le moment.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = NexusTextSecondary,
                                modifier = Modifier.padding(16.dp),
                            )
                        }
                    }
                } else {
                    items(uiState.recentActivities, key = { it.id }) { activity ->
                        ActivityRow(activity = activity)
                    }
                }
            }
        }
    }
}

@Composable
private fun OverviewSummaryCard(
    offlineFirstActive: Boolean,
    monitoredTargets: Int,
    activeRules: Int,
    unreadAlerts: Int,
    onOpenMonitor: () -> Unit,
    onOpenAutomations: () -> Unit,
) {
    Surface(
        color = NexusSurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, NexusOutline),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = if (offlineFirstActive) "Mode hors-ligne actif · Stockage local prêt" else "Mode connecté",
                style = MaterialTheme.typography.labelMedium,
                color = NexusGreen,
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                MetricItem(label = "Cibles", value = monitoredTargets.toString())
                MetricItem(label = "Règles", value = activeRules.toString())
                MetricItem(label = "Alertes", value = unreadAlerts.toString())
            }
            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = NexusOutline)
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Button(
                    onClick = onOpenMonitor,
                    colors = ButtonDefaults.buttonColors(containerColor = NexusGreen),
                    modifier = Modifier.weight(1f),
                ) {
                    Text("Surveiller", fontWeight = FontWeight.SemiBold)
                }
                OutlinedButton(
                    onClick = onOpenAutomations,
                    border = BorderStroke(1.dp, NexusViolet.copy(alpha = 0.5f)),
                    modifier = Modifier.weight(1f),
                ) {
                    Text("Règles", color = NexusViolet)
                }
            }
        }
    }
}

@Composable
private fun MetricItem(label: String, value: String) {
    Column {
        Text(
            text = value,
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = NexusTextSecondary,
        )
    }
}

@Composable
private fun ModuleCard(module: ModuleSummary) {
    Surface(
        color = NexusSurface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, NexusOutline),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Surface(
                color = NexusSurfaceVariant,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.size(42.dp),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = module.type.icon(),
                        contentDescription = null,
                        tint = if (module.status == ModuleStatus.CONFIGURED) NexusGreen else NexusViolet,
                    )
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = module.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    text = module.subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = NexusTextSecondary,
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${module.sprintLabel} · ${module.status.label()}",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (module.status == ModuleStatus.CONFIGURED) NexusGreen else NexusTextSecondary,
                )
            }
        }
    }
}

@Composable
private fun ActivityRow(activity: RecentActivityItem) {
    Surface(
        color = NexusSurface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, NexusOutline),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    text = activity.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    text = activity.timestampLabel,
                    style = MaterialTheme.typography.labelMedium,
                    color = NexusTextSecondary,
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = activity.detail,
                style = MaterialTheme.typography.bodyMedium,
                color = NexusTextSecondary,
            )
        }
    }
}

private fun ModuleType.icon(): ImageVector = when (this) {
    ModuleType.WEB_SENTINEL -> Icons.Outlined.Language
    ModuleType.NETWORK_INTELLIGENCE -> Icons.Outlined.Wifi
    ModuleType.AUTOMATION_ENGINE -> Icons.Outlined.AutoMode
    ModuleType.INTELLIGENCE_ASSISTANT -> Icons.Outlined.Psychology
    ModuleType.SMART_ALERT -> Icons.Outlined.Notifications
    ModuleType.EVENT_INTELLIGENCE -> Icons.Outlined.History
}

private fun ModuleStatus.label(): String = when (this) {
    ModuleStatus.READY -> "Actif"
    ModuleStatus.CONFIGURED -> "Socle prêt"
    ModuleStatus.PLANNED -> "Planifié"
}
