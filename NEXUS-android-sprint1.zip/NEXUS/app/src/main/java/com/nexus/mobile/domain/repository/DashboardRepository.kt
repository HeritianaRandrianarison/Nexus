package com.nexus.mobile.domain.repository

import com.nexus.mobile.domain.model.ModuleSummary
import com.nexus.mobile.domain.model.RecentActivityItem
import com.nexus.mobile.domain.model.SystemOverview
import kotlinx.coroutines.flow.Flow

interface DashboardRepository {
    fun observeSystemOverview(): Flow<SystemOverview>
    fun observeModules(): Flow<List<ModuleSummary>>
    fun observeRecentActivities(): Flow<List<RecentActivityItem>>
    suspend fun refreshOverview()
}
