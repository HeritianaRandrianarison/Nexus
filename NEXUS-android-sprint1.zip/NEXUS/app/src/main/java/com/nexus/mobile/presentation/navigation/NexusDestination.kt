package com.nexus.mobile.presentation.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoMode
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.ui.graphics.vector.ImageVector

enum class NexusDestination(
    val route: String,
    val label: String,
    val icon: ImageVector,
) {
    DASHBOARD("dashboard", "Dashboard", Icons.Outlined.Dashboard),
    MONITOR("monitor", "Monitor", Icons.Outlined.Language),
    AUTOMATIONS("automations", "Rules", Icons.Outlined.AutoMode),
    ACTIVITY("activity", "Activity", Icons.Outlined.History),
    SETTINGS("settings", "Settings", Icons.Outlined.Settings),
}
